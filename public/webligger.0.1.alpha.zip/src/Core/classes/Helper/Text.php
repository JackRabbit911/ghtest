<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Helper;

/**
 * Description of Text
 *
 * @author JackRabbit
 */

use Core\Core;

class Text
{
    public static $markdown = NULL;
    
    public static function markdown($string, $dir=FALSE)
    {
        if(!class_exists('\Parsedown'))
        {
            include_once SRCPATH.'/Core/vendor/Parsedown/Parsedown.php';            
        }
        
        if(self::$markdown === NULL)
        {
            self::$markdown = new \Parsedown();
        }
        
        if($dir === FALSE)
            return self::$markdown->text($string);
        else
        {
            if($file = Core::find_file($string, $dir, 'md'))
            {
                return self::$markdown->text(file_get_contents($file));
            }
            else return NULL;
        }
    }
    
    public static function ns2url($str, $delimeter = '-')
    {
        return strtolower(str_replace('\\', $delimeter, $str));
    }
}
