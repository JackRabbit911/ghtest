<?php
namespace Core\DB\Drivers;

/**
 * Description of Sqlite
 *
 * @author JackRabbit
 */
use Core\DB;

class Sqlite
{
    
    
    public static function truncate($table)
    {
        $sql = DB::select('sql')->from('sqlite_master')
                ->where('type', '=', 'table')
                ->where('tbl_name', '=', $table)
                ->execute(2)->sql;
        
        if(!DB::$pdo->inTransaction()) DB::$pdo->beginTransaction();
        DB::table($table)->drop();        
        $return = DB::$pdo->exec($sql);
        if(DB::$pdo->inTransaction()) DB::$pdo->commit();
        return $return;
    }
    
//    public function __construct($)
//    {
//        ;
//    }
    
    public static function tables()
    {
        $sql = 'SELECT * FROM sqlite_master WHERE type="table" AND tbl_name != "sqlite_sequence"';
        return $sql;
    }
    
    public static function columns($table)
    {
        $sql = "PRAGMA TABLE_INFO ($table)";
        
        return $sql;
    }
    
    public static function is_table()
    {
        $sql = 'SELECT * FROM sqlite_master WHERE type="table" AND tbl_name = ?';
        return $sql;
    }
    
}
