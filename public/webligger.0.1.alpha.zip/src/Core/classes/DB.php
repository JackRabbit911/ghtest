<?php
namespace Core;

/**
 * Description of DB
 *
 * @author JackRabbit
 */
use Core\DB\Query;
use Core\DB\Select;
use Core\DB\Insert;
use Core\DB\Update;
use Core\DB\Delete;
use Core\DB\Create;
use Core\DB\Table;
use Core\DB\Expression;
use Core\DB\Schema;

class DB
{
    use Singletone;
    
    
    const ROW = 2;
    const ALL = 1;

    public static $driver = 'sqlite';
    protected static $dsn = SRCPATH.'App'.DIRECTORY_SEPARATOR.'sqlite'.DIRECTORY_SEPARATOR.'db.sdb';
    
    protected static $connection = array();
    public static $pdo;
    protected static $stmt = array();
    
    public static function connect($driver=NULL, $dsn=NULL)
    {
        if($driver === NULL)
        {
            $driver = static::$driver;
        }
        
        if($dsn === NULL) $dsn = static::$dsn;
        
        $key = $driver.':'.$dsn;
        
        if(!isset(static::$connection[$key]))
        {
            static::$connection[$key] = new \PDO($key);
            static::$connection[$key]->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
            static::$connection[$key]->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_OBJ);
        }
        
        static::$pdo = &static::$connection[$key];
        
        return static::instance();
    }
    
    public static function expr($str)
    {
        return new Expression($str);
    }
    
    public static function query($sql)
    {
        if(!static::$pdo) static::connect();
        return new Query($sql);
       
    }
    
    public function beguin()
    {
        static::$pdo->beginTransaction();
        return $this;
    }
    
    public function end()
    {
        static::$pdo->commit();
        return $this;
    }
    
    public static function select()
    {
        if(!static::$pdo) static::connect();
        return new Select(func_get_args());
    }
    
    public static function insert($table)
    {
        if(!static::$pdo) static::connect();
        return new Insert($table);
    }
    
    public static function update($table)
    {
        if(!static::$pdo) static::connect();
        return new Update($table);
    }
    
    public static function delete($table)
    {
        if(!static::$pdo) static::connect();
        return new Delete($table);
    }
    
    public static function drop($table)
    {
        $sql = 'DROP TABLE '.$table;
        if(!DB::$pdo->inTransaction()) DB::$pdo->beginTransaction();
        $return = DB::$pdo->exec($sql);
        if(DB::$pdo->inTransaction()) DB::$pdo->commit();
        return $return;
    }
    
    public static function create($table)
    {
        if(!static::$pdo) static::connect();
        return new Create($table);
    }
    
    public static function truncate($table)
    {
        $class = __NAMESPACE__.'\Drivers\\'.ucfirst(DB::$driver);
        return $class::truncate($table);
    }

    public static function table($table)
    {
        if(!static::$pdo) static::connect();
        return new Table($table);
    }
    
    public static function schema()
    {
        if(!static::$pdo) static::connect();
        return new Schema(static::$driver);
    }
}
