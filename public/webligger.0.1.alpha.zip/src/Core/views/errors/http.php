<h1 style="text-align: center; color: #a0a0a0;"><?php echo $code ?></h1>
<h2 style="text-align: center; color: #a0a0a0;"><?php echo $message ?></h2>

