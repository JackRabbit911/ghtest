<h4><?=$name?>(<?=implode(', ', $parameters)?>) <small><?=$prefix?></small></h4>
<?=_view('api/doc_comment', $comment);?>
<pre><?=$source?></pre>
    
