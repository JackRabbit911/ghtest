<div class="container">
    <div class="row">
      <div class="col-md-12">              
          <h1>Content block</h1>          
      </div>
    </div>
    <div class="row">
        <div class="col-md-3">
            <?=$sidebar?>
        </div>
        <div class="col-md-9">
            <?=$content?>
        </div>
    </div>
</div>
  