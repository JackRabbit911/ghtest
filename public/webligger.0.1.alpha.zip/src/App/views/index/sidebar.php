<aside class="aside">
        <h4>Sidebar</h4>
        <ul>
        <? foreach($data AS $item): ?>
        <li>
            <a href="<?=$item['link']?>"><?=$item['text']?></a>
        </li> 
        <? endforeach; ?>
        </ul>
</aside> 
  