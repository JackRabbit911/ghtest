

  <div class="container">
      <div class="row">
          <div class="col-md-3">
              <div class="img-wrap">
                  <img id="wn-logo" src="<?=BASEDIR?>/media/img/jukb1.png" class="img-responsive"/>
              </div>
              
          </div>
          <div class="col-md-3">
              
              <h1>Header block</h1>
              <p class="lead">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras eu ultricies ipsum.
              </p>
          </div>
          <div class="col-md-6">
              <p style="margin-top: 40px;">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras eu ultricies ipsum. Quisque dapibus in libero nec tincidunt. 
              Sed ut ante eget neque sodales dignissim nec ac velit. In volutpat tincidunt nisl, eget condimentum risus faucibus vitae. 
              Aliquam facilisis mi eget enim tristique, et imperdiet enim convallis. Pellentesque tristique urna ut mauris semper mattis. 
              Curabitur mauris dui, iaculis ac mi et, consequat semper ex. Cras pretium urna at aliquet eleifend.
              </p>
          </div>
      </div>
  </div>

<div  class="clearfix"></div>

