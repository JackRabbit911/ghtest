<?php
namespace App\Controller;

use Core\Controller;
/**
 * Description of Index
 *
 * @author JackRabbit
 */
class Index extends Controller\Controller
{
    private $template;
    
    private $sidebar;
    private $content;
    
    protected function _before()
    {
        parent::_before();
        
        $this->template = $this->_view('template');
        $this->template->header = $this->_view('header');
        $this->template->content = $this->_view('content');
        $this->template->content->sidebar = $this->_view('index/sidebar')->bind('data', $this->sidebar);
        $this->template->content->content = $this->_view('index/content')->bind('data', $this->content);
        $this->template->footer = $this->_view('footer');
    }
    
    public function index()
    {       
        $model = $this->_model('index');
        
        $this->sidebar = $model->get_sidebar();
        $this->content = $model->get_content();
    }
    
    protected function _after()
    {        
        parent::_after();
        echo $this->template; 
    }

}
