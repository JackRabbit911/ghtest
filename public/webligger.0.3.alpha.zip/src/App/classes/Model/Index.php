<?php
namespace App\Model;
/**
 * Description of Index
 *
 * @author JackRabbit
 */

use Core\DB;

class Index
{
    public function get_leftbar()
    {
        return array(
            array(
                'text'  => 'Первый пункт',
                'link'  => '',
            ),
             array(
                'text'  => 'Второй пункт',
                'link'  => '',
            ),
             array(
                'text'  => 'Третий пункт',
                'link'  => '',
            ),
             array(
                'text'  => 'Четвертый пункт',
                'link'  => '',
            ),
             array(
                'text'  => 'Пятый пункт',
                'link'  => '',
            )
        );
    }
    
    public function get_content()
    {
        return DB::table('pages')->get(1);
    }
}
