<?php
namespace App\Controller;

use Core\Controller;
use User\User;
/**
 * Description of Index
 *
 * @author JackRabbit
 */
abstract class Template extends Controller\Template
{  
    protected $sidebar;
    protected $content;
    protected $user;
    
    protected function _before()
    {
        parent::_before();
        
        $this->user = User::instance();
        static::set_global('user', $this->user);
         
        $this->template->header = $this->_view('header');
        $this->template->content = $this->_view('content');       
        $this->template->footer = $this->_view('footer');
    }
}
