<?php
namespace App\Controller;

//use App\Controller;
/**
 * Description of Index
 *
 * @author JackRabbit
 */
class Index extends \App\Controller\Template
{
   
    public function index()
    {        
        $model = $this->_model('index');
        
        $leftbar = $model->get_leftbar();
        $content = $model->get_content();
        $rightbar = $this->user->control($this->request->post());
        
        $this->template->content->leftbar = $this->_view('index/leftbar')->bind('data', $leftbar);
        $this->template->content->content = $this->_view('index/content')->bind('data', $content);
        $this->template->content->rightbar = $this->_view('index/rightbar')->bind('data', $rightbar);        
    }

}
