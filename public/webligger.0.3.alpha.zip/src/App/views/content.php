<div class="container">
    <div class="row">
      <div class="col-md-12">              
          <h1>Content block</h1>          
      </div>
    </div>
    <div class="row">
        <div class="col-md-3">
            <?=@$leftbar?>
        </div>
        <div class="col-md-5">
            <?=@$content?>
        </div>
        <div class="col-md-4">
            <?=@$rightbar?>
        </div>
    </div>
</div>
  