<aside class="aside">
    <h4>Controls</h4>
       <?=$data?>
</aside> 
  