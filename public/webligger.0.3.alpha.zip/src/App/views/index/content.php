     <article class="article-content">
        <h4>Content</h4>
        <?=@$data->text?>
     </article>   
  