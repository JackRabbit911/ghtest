
<div class="alert alert-success" role="alert">
    Дорогой, <?=$username?> Вы успешно авторизованы.<br>
    На почтовый ящик <?=$email?> ничего не прийдёт, не проверяйте.
</div>