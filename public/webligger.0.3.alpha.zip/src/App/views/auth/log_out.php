
<div class="alert alert-info" role="alert">
    Дорогой, <?=$username?>, нажмите кнопочку, чтобы 
    <button id="<?=uniqid()?>" type="button" class="btn btn-primary" data-action="/user/log_out" data-success="wnLogOut">разлогиниться нахуй</button>
</div>