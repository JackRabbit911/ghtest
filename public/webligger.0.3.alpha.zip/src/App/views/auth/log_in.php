<style>
    .help-block {
        margin-top: 0;
        margin-bottom: 0;
    }
</style>

<form id="<?=uniqid()?>" class="form-horizontal <?=$class?>"  name="<?=$form_name?>" action="" method="post" data-action="/user/auth">
  
    <? foreach($inputs AS $input): ?>
    <? $input = (object)$input; ?>
    
  <div class="form-group <?=$input->class?>">
    <label for="<?=$input->name?>" class="col-sm-4 control-label"><?=$input->label?></label>
    <div class="col-sm-8">
      <input name="<?=$input->name?>" type="<?=$input->type?>" class="form-control" id="<?=$input->name?>" placeholder="<?=$input->plh?>">
      <div class="help-block"><?=$input->error?></div>
    </div>
  </div>
  
     <? endforeach; ?>
    
  <div class="form-group">
    <div class="col-sm-offset-4 col-sm-8">
      <div class="checkbox">
        <label>
          <input type="checkbox"> Запомнить
        </label>
      </div>
    </div>
  </div>
    
  <div class="form-group">
    <div class="col-sm-offset-4 col-sm-8">
      <button type="submit" class="btn btn-default">Отправить</button>
    </div>
  </div>
</form>