$.fn.wnFormSubmit = function(selector, success){

            selector = selector || '';
            success = success || function(elem){
              elem.hide().remove();
              alert('Success!');
              return false;
            };
                  
            $(this).on('submit', 'form'+selector, function(){

                var form = $(this);            
                var action = $(this).data('action');
                var form_data = $(this).serializeArray();

                $.post(
                    action,
                    {form_data:form_data},
                    function(data){            
                        if(data == true) {
                            success(form);
                        } else {
                            form.replaceWith(data);
                        }
                    }
                );
                return false;
              });
        };
        
        $.fn.wnButtonClick = function(){
            
            
            
            $(this).on('click', 'button[data-action]', function(){
                
                
//                alert('qq');
              
              var button = $(this);
              var action = button.data('action');
              var success = button.data('success');
              
//              alert(success);
              
              $.get(action, function(data){
                  eval(success)(button, data);
              });
              return false;
          });
        };
