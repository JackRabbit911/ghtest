<?php
namespace Form;
/**
 * Description of Form
 *
 * @author JackRabbit
 */

use Core\Helper\Arr;
use Core\View;
use Core\Validation;
use Core\Core;

class Form
{
    protected static $_forms = array();
    
    protected $form_name;
    protected $view = 'default';
    public $input = array();
    protected $attr = array();
    protected $rules = array();
//    public $name;
    
    public static function set($form_name, $view_name=NULL)
    {
//        return new static($name);
        
        if(empty(static::$_forms[$form_name]))
            static::$_forms[$form_name] = new static($form_name, $view_name);
        
        return static::$_forms[$form_name];
    }
    
    public function __construct($form_name, $view_name=NULL)
    {
        if($view_name === NULL) $this->view = $form_name;
        else $this->view = $view_name;
        
        $this->form_name = $form_name;
        
        $this->validation = new Validation();
    }


    public static function get($name)
    {
        if(isset(static::$_forms[$name])) return static::$_forms[$name];
        else return FALSE;
    }
    
    public function attr($key, $value)
    {
        $this->attr[$key] = $value;
        return $this;
    }
    
    public function input($name, array $attr = [], array $rule = [])
    {
        if(!isset($this->input[$name]['name'])) $this->input[$name]['name'] = $name;
        
        if(!isset($this->input[$name]['type']))
        {
            if(isset($attr['type'])) $this->input[$name]['type'] = $attr['type'];
            else $this->input[$name]['type'] = 'text';
        }
        elseif(isset($attr['type'])) $this->input[$name]['type'] = $attr['type'];
        
        if(!isset($this->input[$name]['label']))
        {
            if(isset($attr['label'])) $this->input[$name]['label'] = $attr['label'];
            else $this->input[$name]['label'] = $name;
        }
        elseif(isset($attr['label'])) $this->input[$name]['label'] = $attr['label'];
        
        if(!isset($this->input[$name]['plh']))
        {
            if(isset($attr['plh'])) $this->input[$name]['plh'] = $attr['plh'];
            else $this->input[$name]['plh'] = 'Введите '.mb_strtolower($this->input[$name]['label']);
        }
        elseif(isset($attr['plh'])) $this->input[$name]['plh'] = $attr['plh'];
        
        if(!isset($this->input[$name]['value']))
        {
            if(isset($attr['value'])) $this->input[$name]['value'] = $attr['value'];
            else $this->input[$name]['value'] = NULL;
        }
        elseif(isset($attr['value'])) $this->input[$name]['value'] = $attr['value'];
        
        if(!isset($this->input[$name]['class']))
        {
            if(isset($attr['class'])) $this->input[$name]['class'] = $attr['class'];
            else $this->input[$name]['class'] = 'default';
        }
        elseif(isset($attr['class'])) $this->input[$name]['class'] = $attr['class'];
        
        if(!isset($this->input[$name]['error']))
        {
            if(isset($attr['error'])) $this->input[$name]['error'] = $attr['error'];
            else $this->input[$name]['error'] = NULL;
        }
        elseif(isset($attr['error'])) $this->input[$name]['error'] = $attr['error'];
        
        
        $this->rules[$name] = $rule;
        
        return $this;
    }
    
    public function rule()
    { 
        $args = func_get_args();

        $name = array_shift($args);
        $func = array_shift($args);
        
        $this->validation->_rule($name, $func, $args);
        
        return $this;
    }
    
    public function rules()
    {
        $args = func_get_args();
        $name = array_shift($args);
        
        foreach($args AS $func)
        {
            $this->validation->_rule($name, $func);
        }
    }
    
    public function check($post)
    {
        
        
        if(empty($post)) return FALSE;
        
        $this->validation->set_rules($this->rules);
        
        $ok = $this->validation->check($post);
        
        foreach($this->validation->response AS $field=>$response)
        {
            if($response['error'])
            {
                $msg = Core::message($response['error'], [':field'=>$this->input[$field]['label']]);
                $this->input($field, ['class'=>'has-error', 'error'=>$msg]);
            }
            else $this->input($field, ['class'=>'has-success', 'value'=>$response['value']]);
        }
        
//        var_dump($ok); exit;
        
        return $ok;
    }


    public function render()
    {
        $form = View::factory($this->view);

        $form->form_name = $this->form_name;
        
        if(!isset($this->attr['class'])) $this->attr['class'] = 'default';
        
        foreach($this->attr AS $attr=>$value)
        {
            $form->$attr = $value;
        }
        
        $form->inputs = $this->input;
        
//        foreach($this->input AS $name=>$field)
//        {
//            $form->$name = (object) $field;
//        }
        
        return $form->render();
        
    }
}
