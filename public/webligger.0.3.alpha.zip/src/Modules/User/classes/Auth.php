<?php
namespace User;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Form
 *
 * @author JackRabbit
 */
use Form\Form;
use User\Model\Auth as Model;
use Core\Core;
use Core\Session;
use Core\Helper\Arr;
use Core\View;

class Auth
{
    public static function form_log_in($post=NULL)
    {
        $form = Form::set('log_in', 'auth/log_in')
                ->attr('class', 'wn-form')
                ->input('name', ['type'=>'text', 'label'=>'Имя или email'], ['username', 'required'])
                ->input('pass', ['type'=>'text', 'label'=>'Пароль'], ['password']);
        
        
        
//        var_dump($post);
        
        if($form->check($post))
        {
            $name_or_email = $post['name'];
            $password = Arr::get($post, 'pass', '');
            
            if($userdata = Model::sign_in($name_or_email, $password))
            {
                static::force_login($userdata->id);
                return static::success($userdata);
            }
            else
            {
                $form->input('name', ['class'=>'has-error', 'value'=>'', 'error'=>'']);
                $form->input('pass', ['class'=>'has-error', 'value'=>'', 'error'=>Core::message('pair')]);
            }
        }
        
                
        return $form->render();
    }
    
    public static function success($userdata)
    {
        $view = View::factory('auth/success');
        $view->username = $userdata->name;
        $view->email = $userdata->email;
        echo $view->render();
    }
    
    public static function force_login($user_id)
    {
        Session::instance()
                ->start()
                ->set('user_id', $user_id);
    }
    
    public static function auth()
    {
        if($id = Session::instance()->get('user_id'))
        {
            return Model::userdata($id);
        }
        else return FALSE;
    }
    
    public static function form_log_out($username)
    {
        return View::factory('auth/log_out', ['username'=>$username]);
    }
    
    public static function log_out()
    {     
        Session::instance()->destroy();        
        return static::form_log_in();
    }
}
