<?php
namespace User;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Form
 *
 * @author JackRabbit
 */
use User\Auth;

class User
{
    use \Core\Singletone;
    
    public function __construct()
    {
        if($userdata = Auth::auth())
        {
            foreach($userdata AS $key=>$value)
            {
                $this->$key = $value;
            }
        }
        else
        {
            $this->name = 'guest';
            $this->id = FALSE;
        }
    }
    
    public function control($post)
    {
        if($this->id === FALSE)
        {
            return Auth::form_log_in($post);
        }
        else
        {
            return Auth::form_log_out($this->name);
        }
    }
}
