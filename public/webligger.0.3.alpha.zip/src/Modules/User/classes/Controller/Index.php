<?php
namespace User\Controller;

use Core\Controller;
use User\Auth;

/**
 * Description of Index
 *
 * @author JackRabbit
 */
class Index extends Controller\Post
{
    
    public function auth()
    {
//        var_dump($this->request->post()); exit;
        
        echo Auth::form_log_in($this->post);
    }
    
    public function log_out()
    {
        echo Auth::log_out();
    }
    
}
