<?php
namespace User\Model;
/**
 * Description of Auth
 *
 * @author JackRabbit
 */
use Core\DB;

class Auth
{
    public static function sign_in($name_or_email, $password)
    {   
        return DB::select()->from('users')
                ->where('pass', '=', $password)
                ->where('name', '=', $name_or_email)
                ->or_where('email', '=', $name_or_email)                
                ->execute(DB::ROW);
    }
    
    public static function userdata($id)
    {
        return DB::table('users')->get($id);
    }
}
