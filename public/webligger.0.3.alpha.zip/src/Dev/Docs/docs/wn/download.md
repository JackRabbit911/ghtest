## Installation
### Simple download zip-archive
### Use install.php
### Use composer