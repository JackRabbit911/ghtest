$(document).ready(function () {
    var offsetTop = $('nav.sticky-top').wnStickyTop();      
//    $('aside.sidebar').wnContentsUl('article.article-content');
    $('aside.sidebar').wnContentsList('article.article-content');
    $('aside.sidebar').wnSlowScroll(offsetTop);
    $('aside.sidebar').wnScrollSpy(offsetTop);
    $('aside.sidebar').wnAffix();
    
//    alert(offsetTop);
    
});
