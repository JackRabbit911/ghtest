<aside class="sidebar">
    <?=$sidebar?>                        
</aside>