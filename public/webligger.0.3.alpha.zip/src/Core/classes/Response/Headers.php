<?php
namespace Core\Response;
/**
 * Description of Headers
 *
 * @author JackRabbit
 */
class Headers
{
    
}
