<?php
namespace Core;
/**
 * Description of Validation
 *
 * @author JackRabbit
 */
use Core\Core;
use Core\Helper\Arr;
use Core\Exception\Exception;

class Validation
{
    public $_rules = array();
    public $errors = array();
    public $post = array();
    
    public $response = array();
    
    public function __construct(array $rules = [])
    {
        $this->set_rules($rules);       
    }
    
    public function set_rules(array $rules = [])
    {
        foreach($rules AS $name=>$rule)
        {
            if(!is_array($rule))
            {
                $this->_rule($name, $rule);
            }
            else
            {
                foreach($rule AS $key=>$value)
                {
                    if(is_numeric($key))
                    {          
                        $this->_rule($name, $value);
                    }
                    else
                    {
                        $this->_rule($name, $key, $value);
                    }
                }
            }
        }
    }
    
    public function rules()
    {
        $args = func_get_args();
        $name = array_shift($args);
        
        foreach($args AS $func)
        {
            $this->_rule($name, $func);
        }
    }
    
    public function rule()
    { 
        $args = func_get_args();
        
//        var_dump($args); exit;
        
        
        $name = array_shift($args);
        $func = array_shift($args);
        
//        var_dump($args); exit;
        
        $this->_rule($name, $func, $args);
        
        return $this;
    }
    
    public function _rule($name, $func, array $args = array())
    {
//        $func = array_shift($args);
        
        if($func)
        {
//            var_dump($args); exit;
            
            
            $this->_rules[$name][$func] = $args;
        
            $datatype = Core::config('datatypes', $func, TRUE);
         
            if($datatype)
            {
                
                $datarules = $this->_datatype($datatype);
                
//                var_dump($datarules);
//                var_dump($this->_rules[$name]);
                
                $this->_rules[$name] = array_replace_recursive($datarules, $this->_rules[$name]);
                
                
                if(!method_exists($this, $func)) unset($this->_rules[$name][$func]);
            }
            
        }
    }
    
    protected function _datatype($datatype)
    {
        $result = [];
        
        if(is_array($datatype) && !empty($datatype))
        {

            if(isset($datatype[0]) && is_array($datatype[0]))
            {
                foreach($datatype AS $item)
                {
                    $result = array_merge($result, $this->_datatype($item));
                }
            }
            else
            {
                $func = array_shift($datatype);
                
                $result[$func] = $datatype;
                
//                $arg = $datatype;
//                $result[$func] = $arg;
            }
        }
        
        return $result;
    }


    public function check($post, $message=TRUE)
    {
       $this->post = &$post;
        
       $errors = [];
       $ok = TRUE;
        
       foreach($post AS $name=>$value)
       {                  
           if(isset($this->_rules[$name]) && is_array($this->_rules[$name]))
           {
               if(isset($this->_rules[$name]['required']))
               {
                   $r = $this->_rules[$name]['required'];
                   if(is_array($r) && empty($r)) $r = [TRUE];
                   unset($this->_rules[$name]['required']);
               }
               else $r = [FALSE];
               
               $code = $this->required($value, $r);
               
               if($code !== 'required')
               {                   
                   $code = $this->_check($this->_rules[$name], $value);
               }
               
//               if($message === TRUE)
//                    $errors[$name] = Core::message($code, [':field'=>$name]);
//               else $errors[$name] = $code;
//               
//               if(!$errors[$name])
//               {
//                   $errors[$name] = FALSE; //unset($this->errors[$name]);
//                   $values[$name] = $value;
//               }
//               else 
//               {
//                   $values[$name] = NULL;
//                   
//                   $ok = FALSE;
//                   
////                   echo $name.' - '; var_dump($ok);
//               }
           }
           else $code = NULL;
           
           if($code)
           {
               $this->response[$name]['value'] = NULL;
               $ok = FALSE;
           }
           else
           {
               $this->response[$name]['value'] = $value;
           }
           $this->response[$name]['error'] = $code;
//           $this->response[$name]['value'] = ($code) ? NULL : $value;
           
       }
       
//       $this->errors = $errors;
//       $this->values = $values;
//       $this->ok = $ok;
       
       return $ok;
       
//       return ['errors'=>$errors, 'success'=>$ok, 'values'=>$values];
       
    }
    
    
    protected function _check($rule, $value)
    {
        
//        var_dump($rule); exit;
        
        $error = NULL;
        
        foreach($rule AS $func => $arg)
        {
           
            
           if($func === 'callback')
           {
               $func = array_shift($arg);
           }
           else $func = [$this, $func];
           
           
           if(isset($arg[0]) && is_array($arg[0]))
               $arg = $arg[0];
           
           
//           echo '<br>class - ';  var_dump($class); exit;
//           echo '<br>func - ';  var_dump($func); //exit;
//           echo '<br>value - ';  var_dump($value);
//           echo '<br>arg - ';  var_dump($arg);
//           exit;
           
           $error = call_user_func($func, $value, $arg);
               
           if($error != NULL) break;
        }
        
        return $error;
    }
    
    public function required($value, $arg)
    {
        if($arg[0] === TRUE)
        {
            return ($value === '') ? 'required' : NULL;
        }
        else return NULL;
    }
    
    protected function min_lenth($str, $lenth)
    {
//        var_dump($lenth);
        
        if(empty($lenth[0])) return NULL;
        else $lenth = $lenth[0];
        
        if(mb_strlen($str) < $lenth) return 'min_lenth';
        else return NULL;
    }
    
    protected function max_lenth($str, $lenth)
    {
        if(empty($lenth[0])) return NULL;
        else $lenth = $lenth[0];
        
        if(mb_strlen($str) > $lenth) return 'max_lenth';
        else return NULL;
    }
    
    protected function range($str, array $range = [])
    {
        if(empty($range)) return NULL;
        if(isset($range[0]))
        {
            if(mb_strlen($str) < $range[0]) return 'min_lenth';
        }
        if(isset($range[1]))
        {
            if(mb_strlen($str) > $range[1]) return 'max_lenth';
        }
        return NULL;
    }
    
    protected function confirm($str, $arg)
    {
//        var_dump($arg);        
//        exit;
        
        $name = $arg[0];
        
        return ((string)$str === (string)$this->post[$name]) ? NULL : 'confirm';
    }


    public function regexp($str, $options)
    {
        $regex = $options[0];
        
        $error = Arr::get($options, 1, 'regex');
        
        if(preg_match($regex, $str) === 0) return $error;

        else return NULL;
    }
    
    protected function date($str, $options)
    {
//        var_dump($str);
//        var_dump($options);
        
        
        $format = Arr::get($options, 0, 'd.m.Y');
        $d = \DateTime::createFromFormat($format, $str);
        if($d && $d->format($format) == $str) return NULL;
        else return 'date';
    }
    
    public function filter($var, $filter)
    {      
        $validate = array_shift($filter);
        
        
        if(!empty($filter[0]) && is_array($filter[0]))
            $filter = $filter[0];
        
//        var_dump($filter); exit;
        
        $error = Arr::get($filter, 'error', 'unknown error');
        if(isset($filter['error'])) unset($filter['error']);

        if(!filter_var($var, $validate, $filter)) return $error;
        else return NULL;
    }
}
