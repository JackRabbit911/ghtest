<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Helper;

/**
 * Description of Text
 *
 * @author JackRabbit
 */

use Core\Core;

class Text
{
    public static $markdown = NULL;
    
    public static function markdown($string, $dir=FALSE, $tag = FALSE)
    {
        if(!class_exists('\Parsedown'))
        {
            include_once SRCPATH.'/Core/vendor/Parsedown/Parsedown.php';            
        }
        
        if(self::$markdown === NULL)
        {
            self::$markdown = new \Parsedown();
        }
        
        if($dir === FALSE)
            $result = self::$markdown->text($string);
        else
        {
            if($file = Core::find_file($string, $dir, 'md'))
            {
                $result = self::$markdown->text(file_get_contents($file));
            }
            else return NULL;
        }
        
        if($tag !== FALSE)
        {
            $result = static::htmlspecialchars($result, $tag);
        }
        
        return $result;
    }
    
   
    
    public static function htmlspecialchars($str, $tag)
    {
        $regex = '|(<'.$tag.'>)(.*)(</'.$tag.'>)|isU';
        
        return preg_replace_callback($regex, function($m){
            $m[2] = htmlspecialchars($m[2]);
            return $m[1].$m[2].$m[3];
        }, $str);
    }
    
}
