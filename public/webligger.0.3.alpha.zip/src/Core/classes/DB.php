<?php
namespace Core;

/**
 * Description of DB
 *
 * @author JackRabbit
 */
use Core\Core;
use Core\DB\Query;
use Core\DB\Select;
use Core\DB\Insert;
use Core\DB\Update;
use Core\DB\Delete;
use Core\DB\Create;
use Core\DB\Table;
use Core\DB\Expression;
use Core\DB\Schema;

class DB
{
    use Singletone;
    
    
    const ROW = 2;
    const ALL = 1;

    public static $driver = 'sqlite';
    protected static $sqlite_path = SRCPATH.'App'.DIRECTORY_SEPARATOR.'sqlite'.DIRECTORY_SEPARATOR;
    
    protected static $connection = array();
    public static $pdo;
    protected static $stmt = array();
    
    public static function connect($driver=NULL, $dsn=NULL, $username=NULL, $password=NULL)
    {
        if($driver === NULL)
        {
            $driver = static::$driver;
        }
        else static::$driver = $driver;
        
        $connect = Core::config('connect', $driver);
        
//        var_dump($connect); exit;
        
        
        $func = '_'.$driver;
        
        if(method_exists('\Core\DB', $func))
        {           
            $paramsPDO = call_user_func(array('\Core\DB', $func), $connect);
        }
        
        if($dsn === NULL && !empty($paramsPDO->dsn)) $dsn = $paramsPDO->dsn;
        else 
        {
            
            if($driver === 'sqlite')
            {
                $dsn = str_replace('/', DIRECTORY_SEPARATOR, $dsn);
                if(strpos($dsn, static::$sqlite_path) === FALSE)
                    $dsn = static::$sqlite_path.$dsn;
            }
            $dsn = $driver.':'.$dsn;
        }
        if($username === NULL && !empty($paramsPDO->username)) $username = $paramsPDO->username;
        if($password === NULL && !empty($paramsPDO->password)) $password = $paramsPDO->password;
        
//        if($dsn === NULL)
//        {
//            $dsn = static::$dsn;
//        }
        
//        $key = $driver.':'.$dsn;
//        echo $dsn; exit;
//        $key = $dsn;
        
        if(!isset(static::$connection[$dsn]))
        {
            static::$connection[$dsn] = new \PDO($dsn, $username, $password);
            static::$connection[$dsn]->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
            static::$connection[$dsn]->setAttribute(\PDO::ATTR_DEFAULT_FETCH_MODE, \PDO::FETCH_OBJ);
        }
        
        static::$pdo = &static::$connection[$dsn];
        
        return static::instance();
    }
    
    public static function expr($str)
    {
        return new Expression($str);
    }
    
    public static function query($sql)
    {
        if(!static::$pdo) static::connect();
        return new Query($sql);
       
    }
    
    public function beguin()
    {
        static::$pdo->beginTransaction();
        return $this;
    }
    
    public function end()
    {
        static::$pdo->commit();
        return $this;
    }
    
    public static function select()
    {
        if(!static::$pdo) static::connect();
        return new Select(func_get_args());
    }
    
    public static function insert($table)
    {
        if(!static::$pdo) static::connect();
        return new Insert($table);
    }
    
    public static function update($table)
    {
        if(!static::$pdo) static::connect();
        return new Update($table);
    }
    
    public static function delete($table)
    {
        if(!static::$pdo) static::connect();
        return new Delete($table);
    }
    
    public static function drop($table)
    {
        $sql = 'DROP TABLE '.$table;
        if(!DB::$pdo->inTransaction()) DB::$pdo->beginTransaction();
        $return = DB::$pdo->exec($sql);
        if(DB::$pdo->inTransaction()) DB::$pdo->commit();
        return $return;
    }
    
    public static function create($table)
    {
        if(!static::$pdo) static::connect();
        return new Create($table);
    }
    
    public static function truncate($table)
    {
        $class = __NAMESPACE__.'\Drivers\\'.ucfirst(DB::$driver);
        return $class::truncate($table);
    }

    public static function table($table)
    {
        if(!static::$pdo) static::connect();
        return new Table($table);
    }
    
    public static function schema()
    {
        if(!static::$pdo) static::connect();
        return new Schema(static::$driver);
    }
    
    protected static function _sqlite(array $array = array())
    {
        $paramsPDO = new \stdClass();
        
        if(isset($array['path'])) $path = SRCPATH.$array['path'].DIRECTORY_SEPARATOR;
        else $path = static::$sqlite_path; //SRCPATH.'App'.DIRECTORY_SEPARATOR.'sqlite'.DIRECTORY_SEPARATOR;
        
        if(!isset($array['dbname'])) $array['dbname'] = 'db.sdb';
        
        
        $paramsPDO->dsn = 'sqlite:'.$path.$array['dbname'];
        $paramsPDO->username = NULL;
        $paramsPDO->password = NULL;
        $paramsPDO->path = $path;
        
//        static::$dbname = $array['dbname'];
        
        return $paramsPDO;
    }
    
    protected static function _mysql(array $array = array())
    {
        $paramsPDO = new \stdClass();
        
        $paramsPDO->dsn = 'mysql:dbname='.$array['dbname'].';host='.$array['host'];
        $paramsPDO->username = $array['username'];
        $paramsPDO->password = $array['password'];
        
//        static::$dbname = $array['dbname'];
        
        return $paramsPDO;
    }
}
