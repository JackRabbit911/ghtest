<?php
namespace Core\Controller;

use Core\Controller;

/**
 * Description of Index
 *
 * @author JackRabbit
 */
class Post extends Controller\Controller
{
    protected $post;
    
    protected function _before()
    {
        parent::_before();
        
//        var_dump($this->request->post()); exit;
        
        if($this->request->is_ajax() && !empty($this->request->post('form_data')))
        {
            $this->post = $this->_unserialize($this->request->post('form_data'));
        }
        else $this->post = $this->request->post();
    }
    
    protected function _unserialize($array)
    {
        $result = [];
        foreach($array AS $item)
        {
            $result[$item['name']] = $item['value'];
        }
        return $result;
    }
    
}
