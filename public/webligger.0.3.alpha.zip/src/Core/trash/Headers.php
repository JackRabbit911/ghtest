<?php
namespace Core\Request;

/**
 * Description of Headers
 *
 * @author JackRabbit
 */

use Core\Request\Internal; // as Request;

class Headers
{
//    public static function cache_control()
//    {
//        return Request::headers('cache_control');
//    }
    
}
