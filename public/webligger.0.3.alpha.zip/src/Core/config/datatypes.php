<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

return [
//    'string'    => [],
    'username'  => ['regexp', '/^[\w\s-@.]+$/u', 'username'],
    'password'  => ['regexp', '/^[\w\s-@.]*$/u', 'password'],
//    'confim'    => [
//        'confirm' => 'password',
//    ],
//    'date'      => [
//        'date' => ':format',
//    ],
//    'boolean'   => 'boolean',
    'email'         => ['filter', FILTER_VALIDATE_EMAIL, 'error'=>'email'],
    'integer'       => ['filter', FILTER_VALIDATE_INT, 'error'=>'integer'],
    'alpha_num'     => ['regexp', '/^[a-zA-Z0-9]+$/', 'alpha_num'],
    'alpha_utf8'    => ['regexp', '/^[\pL]+$/u', 'alpha_utf8'],
    'alpha_num_utf8'=> ['regexp', '/^[\w]+$/u', 'alpha_num_utf8'],
    'phone'         => ['regexp', '/^[\+\s\d-()]{3,20}$/', 'phone'],
    'phone_strict'  => ['regexp', '/^[\d]{11,11}$/', 'phone_strict'],
    'date'          => ['date', 'd.m.Y'],
];

