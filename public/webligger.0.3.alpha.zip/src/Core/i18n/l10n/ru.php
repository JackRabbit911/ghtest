<?php

return [
    'lang_name' => 'Русский', 
    'flag'      =>'ru.gif', 
    'date'      =>'d.m.Y', 
    'time'      =>'H.m',
    'float'     =>'3 . &nbsp;',
    'currency'  =>'&#8381;'
];

