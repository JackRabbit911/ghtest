<?php

return [
    'lang_name' => 'English', 
    'flag'=>'us.png', 
    'currency'=>'$', 
];

