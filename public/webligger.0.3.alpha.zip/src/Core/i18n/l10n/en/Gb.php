<?php

return [
    'lang_name' => 'English', 
    'flag'=>'gb.png', 
    'currency'=>'&#163;', 
];

