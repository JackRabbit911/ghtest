<?php

return [
    'lang_name' => 'English', 
    'flag'=>'gb.png', 
    'date'=>'m/d/Y', 
    'time'=>'h:m A',
    'float'=>'4 , &nbsp;',
];

